

<?php $__env->startSection('content'); ?>
    <!-- Iframe ini hanya akan muncul saat menu UTS diklik -->
    <iframe src="<?php echo e(asset('Pendaftaran/form.html')); ?>" width="100%" height="500" frameborder="0"></iframe>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\diana-laravel\resources\views/menu/uts.blade.php ENDPATH**/ ?>